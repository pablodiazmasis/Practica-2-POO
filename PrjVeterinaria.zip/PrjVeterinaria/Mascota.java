import java.time.LocalDate;

/**
 * Representa a una mascota dentro del sistema de gestión de la clínica veterinaria.
 * Permite almacenar información básica del animal (nombre, raza y año de nacimiento),
 * calcular su edad cronológica y su equivalente en edad humana, así como gestionar
 * la relación con la persona veterinaria asignada a su cuidado.
 * 
 * @author Pablo Díaz M.
 * @version 21.0.6 (2026).
 */
public class Mascota {
    
    /**
     * Nombre de la mascota.
     */
    private String nombre;

    /**
     * Raza a la que pertenece la mascota.
     */
    private String raza;

    /**
     * Año en que nació la mascota. Si no se registra, su valor por defecto es 0.
     */
    private int anioNacimiento = 0;

    /**
     * Referencia a la persona veterinaria asignada para la atención de la mascota.
     */
    private Persona miVeterinario;

    /**
     * Construye una nueva instancia de Mascota indicando todos sus datos biográficos.
     *
     * @param nombre         Nombre de la mascota.
     * @param raza           Raza de la mascota.
     * @param anioNacimiento Año de nacimiento de la mascota.
     */
    public Mascota(String nombre, String raza, int anioNacimiento) {
        this.nombre = nombre;
        this.raza = raza;
        this.anioNacimiento = anioNacimiento;
    }
    
    /**
     * Construye una nueva instancia de Mascota cuando no se especifica el año de nacimiento.
     * Inicializa el año de nacimiento con el valor por defecto de 0.
     *
     * @param nombre Nombre de la mascota.
     * @param raza   Raza de la mascota.
     */
    public Mascota(String nombre, String raza) {
        this(nombre, raza, 0);
    }
    
    /**
     * Asocia una persona veterinaria al cuidado de esta mascota.
     *
     * @param veterinario Objeto de tipo Persona correspondiente al profesional asignado.
     */
    public void asignarVeterinario(Persona veterinario) {
        this.miVeterinario = veterinario;
    }
    
    /**
     * Consulta el nombre de la persona veterinaria asignada a la mascota.
     *
     * @return Mensaje con el nombre del veterinario o un texto indicando que aún
     *         no tiene un profesional asignado.
     */
    public String consultarNombreVeterinario() {
        if (miVeterinario == null) {
            return "No tiene veterinario asignado actualmente.";
        }
        return "Veterinario asignado: " + miVeterinario.getNombre();
    }

    /**
     * Calcula la edad actual de la mascota en años caninos restando el año de nacimiento al año actual.
     * Si el año de nacimiento no fue registrado (valor 0), la edad calculada es 0.
     *
     * @return Edad canina en años cumplidos.
     */
    private int calcularEdadCanina() {
        if (anioNacimiento == 0) {
            return 0;
        }
        return obtenerAnioActual() - anioNacimiento;
    }
    
    /**
     * Calcula el equivalente de la edad de la mascota en años humanos multiplicando la edad canina por 7.
     * Si el año de nacimiento no fue registrado (valor 0), la edad calculada es 0.
     *
     * @return Equivalente de la edad en años humanos.
     */
    private int calcularEdadHumana() {
        if (anioNacimiento == 0) {
            return 0;
        }
        return calcularEdadCanina() * 7;
    }
    
    /**
     * Obtiene el nombre de la mascota.
     *
     * @return Cadena de texto con el nombre.
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * Obtiene el año en curso a través de la fecha del sistema.
     *
     * @return Año actual como valor entero.
     */
    private int obtenerAnioActual() {
        return LocalDate.now().getYear();
    }
    
    /**
     * Verifica si la mascota ya tiene una persona veterinaria asignada.
     *
     * @return true si ya cuenta con veterinario asignado; false en caso contrario.
     */
    public boolean tieneVeterinario() {
        return this.miVeterinario != null;
    }    
    
    /**
     * Genera una representación en texto del estado completo de la mascota, incluyendo
     * nombre, raza, año de nacimiento, edad canina actual y edad humana equivalente.
     *
     * @return Cadena formateada con la información detallada de la mascota.
     */
    @Override
    public String toString() {
        String mensaje = "======= Información de mascota =======\n";
        mensaje += "Nombre: " + nombre + "\n";
        mensaje += "Raza: " + raza + "\n";
        mensaje += "Año de nacimiento: " + anioNacimiento + "\n";
        mensaje += "Edad canina: " + calcularEdadCanina() + "\n";
        mensaje += "Edad humana: " + calcularEdadHumana() + "\n";
        
        return mensaje;
    }
}