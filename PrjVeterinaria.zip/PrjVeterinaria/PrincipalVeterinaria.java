import java.util.ArrayList;
import java.util.Scanner;

public class PrincipalVeterinaria {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Persona> veterinarios = new ArrayList<>();
        ArrayList<Mascota> mascotas = new ArrayList<>();

        String nombreFuncionario;
        String nombreMascota;
        boolean salir = false;

        while (!salir) {
            System.out.println("\nSISTEMA DE GESTIÓN DE VET-WAIN\n");
            System.out.println("========== MENÚ PRINCIPAL ==========");
            System.out.println("1. Registrar funcionario");
            System.out.println("2. Registrar mascota");
            System.out.println("3. Asignar mascota al cuidado de un funcionario");
            System.out.println("4. Lista del estado de los funcionarios");
            System.out.println("5. Consultar el estado de una mascota");
            System.out.println("6. Consultar el funcionario encargado de una mascota");
            System.out.println("7. Consultar listado de mascotas de un funcionario");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            String entradaOpcion = scanner.nextLine().trim();
            int opcion;

            try {
                opcion = Integer.parseInt(entradaOpcion);
            } catch (NumberFormatException e) {
                System.out.println("Error: debe ingresar un valor numérico.");
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("\nDigite el nombre del funcionario: ");
                    nombreFuncionario = scanner.nextLine().trim();

                    System.out.print("Ingrese el código de licencia del funcionario: ");
                    String codLicencia = scanner.nextLine().trim();

                    if (nombreFuncionario.isEmpty()) {
                        System.out.println("Error: el nombre no puede estar vacío.");
                        break;
                    }

                    Persona persona = new Persona(nombreFuncionario, codLicencia);
                    veterinarios.add(persona);
                    System.out.println("Funcionario '" + persona.getNombre() + "' registrado con éxito.");
                    break;

                case 2:
                    System.out.print("\nDigite el nombre de la mascota: ");
                    nombreMascota = scanner.nextLine().trim();
                
                    System.out.print("Ingrese la raza de la mascota: ");
                    String raza = scanner.nextLine().trim();
                
                    if (nombreMascota.isEmpty()) {
                        System.out.println("Error: el nombre no puede estar vacío.");
                        break;
                    }
                
                    if (raza.isEmpty()) {
                        System.out.println("Error: la raza no puede estar vacía.");
                        break;
                    }
                
                    System.out.print("Ingrese el año de nacimiento de la mascota (dejar vacío si el año es cero): ");
                    String anioNacimientoStr = scanner.nextLine().trim();
                
                    Mascota mascota;
                
                    if (anioNacimientoStr.isEmpty()) {
                        mascota = new Mascota(nombreMascota, raza);
                    } else {
                        if (!validarEntradaInt(anioNacimientoStr)) {
                            break; 
                        }
                        
                        int anioNacimiento = Integer.parseInt(anioNacimientoStr);
                        
                        mascota = new Mascota(nombreMascota, raza, anioNacimiento);
                    }
                
                    mascotas.add(mascota);
                    System.out.println("Mascota '" + mascota.getNombre() + "' registrada con éxito.");
                    break;

                case 3:
                    if (veterinarios.isEmpty()) {
                        System.out.println("\nNo hay funcionarios registrados.");
                        break;
                    }
                    
                    if (mascotas.isEmpty()) {
                        System.out.println("\nNo hay mascotas registradas.");
                        break;
                    }

                    System.out.println("\n========== LISTA DE FUNCIONARIOS ==========");
                    for (Persona p : veterinarios) {
                        System.out.println("- " + p.getNombre());
                    }

                    System.out.println("\n========== LISTA DE MASCOTAS ==========");
                    for (Mascota m : mascotas) {
                        System.out.println("- " + m.getNombre());
                    }

                    System.out.print("\nDigite el nombre del funcionario a asignar: ");
                    nombreFuncionario = scanner.nextLine().trim();

                    System.out.print("Digite el nombre de la mascota a asignar: ");
                    nombreMascota = scanner.nextLine().trim();

                    if (nombreFuncionario.isEmpty() || nombreMascota.isEmpty()) {
                        System.out.println("Error: los nombres no pueden estar vacíos.");
                        break;
                    }

                    Persona funcionarioEncontrado = null;
                    Mascota mascotaEncontrada = null;

                    for (Persona p : veterinarios) {
                        if (p.getNombre().equalsIgnoreCase(nombreFuncionario)) {
                            funcionarioEncontrado = p;
                            break;
                        }
                    }

                    for (Mascota m : mascotas) {
                        if (m.getNombre().equalsIgnoreCase(nombreMascota)) {
                            mascotaEncontrada = m;
                            break;
                        }
                    }

                    if (funcionarioEncontrado == null) {
                        System.out.println("Error: No se encontró ningún funcionario con el nombre '" + nombreFuncionario + "'.");
                        break;
                    }

                    if (mascotaEncontrada == null) {
                        System.out.println("Error: No se encontró ninguna mascota con el nombre '" + nombreMascota + "'.");
                        break;
                    }
                    
                    if (mascotaEncontrada.tieneVeterinario()) {
                        System.out.println("Error: La mascota '" + mascotaEncontrada.getNombre() + "' ya tiene asignada una persona veterinaria (" 
                            + mascotaEncontrada.consultarNombreVeterinario() + ").");
                        break;
                    }

                    // funcionario guarda mascota y mascota guarda veterinario
                    funcionarioEncontrado.asignarMascota(mascotaEncontrada);
                    mascotaEncontrada.asignarVeterinario(funcionarioEncontrado);
                    System.out.println("Mascota '" + mascotaEncontrada.getNombre() + "' asignada exitosamente a " + funcionarioEncontrado.getNombre() + ".");
                    break;

                case 4:
                    if (veterinarios.isEmpty()) {
                        System.out.println("\nNo hay funcionarios registrados.");
                    } else {
                        System.out.println("\n========== LISTA DE FUNCIONARIOS ==========");
                        for (Persona p : veterinarios) {
                            System.out.println(p);
                            System.out.println();
                        }
                    }
                    break;

                case 5:
                    if (mascotas.isEmpty()) {
                        System.out.println("\nNo hay mascotas registradas.");
                        break;
                    }
                
                    System.out.print("\nDigite el nombre de la mascota a consultar: ");
                    nombreMascota = scanner.nextLine().trim();
                
                    if (nombreMascota.isEmpty()) {
                        System.out.println("Error: el nombre de la mascota no puede estar vacío.");
                        break;
                    }
                
                    mascotaEncontrada = null;
                    for (Mascota m : mascotas) {
                        if (m.getNombre().equalsIgnoreCase(nombreMascota)) {
                            mascotaEncontrada = m;
                            break;
                        }
                    }
                
                    if (mascotaEncontrada != null) {
                        System.out.println("\n" + mascotaEncontrada);
                    } else {
                        System.out.println("Error: No se encontró ninguna mascota con el nombre '" + nombreMascota + "'.");
                    }
                    break;

                case 6:
                    if (mascotas.isEmpty()) {
                        System.out.println("\nNo hay mascotas registradas.");
                        break;
                    }

                    System.out.print("\nDigite el nombre de la mascota a buscar: ");
                    nombreMascota = scanner.nextLine().trim();

                    if (nombreMascota.isEmpty()) {
                        System.out.println("Error: el nombre de la mascota no puede estar vacío.");
                        break;
                    }

                    mascotaEncontrada = null;
                    for (Mascota m : mascotas) {
                        if (m.getNombre().equalsIgnoreCase(nombreMascota)) {
                            mascotaEncontrada = m;
                            break;
                        }
                    }

                    if (mascotaEncontrada != null) {
                        System.out.println("\n" + mascotaEncontrada.consultarNombreVeterinario());
                    } else {
                        System.out.println("Error: No se encontró la mascota '" + nombreMascota + "'.");
                    }
                    break;

                case 7:
                    if (veterinarios.isEmpty()) {
                        System.out.println("\nNo hay funcionarios registrados.");
                        break;
                    }

                    System.out.print("\nDigite el nombre del funcionario a consultar: ");
                    nombreFuncionario = scanner.nextLine().trim();

                    if (nombreFuncionario.isEmpty()) {
                        System.out.println("Error: el nombre del funcionario no puede estar vacío.");
                        break;
                    }

                    funcionarioEncontrado = null;
                    for (Persona p : veterinarios) {
                        if (p.getNombre().equalsIgnoreCase(nombreFuncionario)) {
                            funcionarioEncontrado = p;
                            break;
                        }
                    }

                    if (funcionarioEncontrado != null) {
                        System.out.println("\n========== MASCOTAS A CARGO DE " + funcionarioEncontrado.getNombre().toUpperCase() + " ==========");
                        
                        String listaMascotas = funcionarioEncontrado.consultarMascotas();
                        
                        if (listaMascotas.isEmpty()) {
                            System.out.println("Este funcionario no tiene mascotas asignadas aún.");
                        } else {
                            System.out.println(listaMascotas);
                        }
                        
                    } else {
                        System.out.println("Error: No se encontró el funcionario '" + nombreFuncionario + "'.");
                    }
                    break;

                case 0:
                    System.out.println("\nSaliendo del sistema de gestión de VET-WAIN.");
                    salir = true;
                    break;

                default:
                    System.out.println("Opción no válida. Digite un número del 0 al 7.");
                    break;
            }
        }
        scanner.close();
    }
    
    private static boolean validarEntradaInt(String entrada) {
        if (entrada == null || entrada.isBlank()) {
            System.out.println("Error: debe ingresar un valor numérico.");
            return false;
        }

        try {
            int valor = Integer.parseInt(entrada);
            if (valor < 0) {
                System.out.println("Error: el valor no puede ser negativo.");
                return false;
            }
            return true;
        } catch (NumberFormatException e) {
            System.out.println("Error: debe ingresar un número válido.");
            return false;
        }
    }
}