import java.util.ArrayList;

/**
 * Representa a un profesional veterinario dentro del sistema de la clínica.
 * Permite gestionar sus datos básicos de identificación y las mascotas
 * que tiene asignadas a su cuidado.
 * 
 * @author Pablo Díaz M.
 * @version 21.0.6 (2026).
 */
public class Persona {

    /**
     * Nombre completo del funcionario veterinario.
     */
    private String nombre;

    /**
     * Código de licencia profesional del veterinario.
     */
    private String codLicencia;

    /**
     * Colección de mascotas asignadas al cuidado del veterinario.
     */
    private ArrayList<Mascota> misMascotas;

    /**
     * Construye un nuevo registro de un funcionario veterinario.
     * Inicializa la lista interna de mascotas asignadas.
     *
     * @param nombre      Nombre de la persona veterinaria.
     * @param codLicencia Código de licencia profesional única.
     */
    public Persona(String nombre, String codLicencia) {
        this.nombre = nombre;
        this.codLicencia = codLicencia;
        this.misMascotas = new ArrayList<>();
    }

    /**
     * Obtiene el nombre del funcionario veterinario.
     *
     * @return Cadena de texto con el nombre.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Asigna una nueva mascota a la lista de animales a cargo del veterinario.
     *
     * @param mascota Instancia de la mascota que se va a asignar.
     */
    public void asignarMascota(Mascota mascota) {
        misMascotas.add(mascota);
    }

    /**
     * Genera una lista con los nombres de todas las mascotas asignadas al funcionario,
     * separadas por saltos de línea.
     *
     * @return Cadena de texto con el listado de nombres de las mascotas, o un mensaje
     *         indicando que no tiene mascotas a cargo si la lista está vacía.
     */
    public String consultarMascotas() {
        if (misMascotas.isEmpty()) {
            return "No tiene mascotas asignadas.";
        }

        String lista = "";
        for (Mascota m : misMascotas) {
            lista += "- " + m.getNombre() + "\n";
        }

        return lista.trim();
    }

    /**
     * Retorna una representación textual con el estado completo del veterinario,
     * incluyendo su nombre y código de licencia profesional.
     *
     * @return Cadena formateada con la información del funcionario.
     */
    @Override
    public String toString() {
        String mensaje = "======= Información del veterinario =======\n";
        mensaje += "Nombre: " + nombre + "\n";
        mensaje += "Código de licencia: " + codLicencia + "\n";

        return mensaje;
    }
}